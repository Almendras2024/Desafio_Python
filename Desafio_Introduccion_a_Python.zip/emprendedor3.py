import math


# Solicitar al usuario los datos de entrada
precio_suscripcion = float(input("Ingrese el precio de suscripción (P): \n"))
usuarios_normales = int(input("Ingrese el número de usuarios normales (U): \n"))
gastos_totales = float(input("Ingrese los gastos totales (GT): \n"))
utilidades_anterior = float(input("Ingrese las utilidades del año anterior que sea distinto a cero (Uanterior): \n"))

# Calcular las utilidades actuales según la fórmula
utilidades_actuales = precio_suscripcion * usuarios_normales - gastos_totales

# Calcular la razón entre las utilidades actuales y las del año anterior
razon_utilidades = utilidades_actuales / utilidades_anterior if utilidades_anterior != 0 else 0

# Imprimir el resultado redondeado a dos decimales
print(f"La razón entre las utilidades actuales y las del año anterior es: {razon_utilidades:.2f}")