import math

# Solicitar al usuario los datos de entrada
precio_suscripcion = float(input("Ingrese el precio de suscripción (P): \n"))
usuarios_normales = int(input("Ingrese el número de usuarios normales (Unormal): \n"))
usuarios_premium = int(input("Ingrese el número de usuarios premium (Upremium): \n"))
gastos_totales = float(input("Ingrese los gastos totales (GT): \n"))

# Calcular las utilidades considerando el precio premium
utilidades = (precio_suscripcion * usuarios_normales) + (precio_suscripcion * 1.5 * usuarios_premium) - gastos_totales

# Imprimir el resultado
print(f"Las utilidades del proyecto son: {utilidades:.2f} USD")