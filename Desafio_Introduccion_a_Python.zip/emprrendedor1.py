import math

# Solicitar al usuario los datos de entrada
precio_suscripcion = float(input("Ingrese el precio de suscripción (P): \n"))
num_usuarios = int(input("Ingrese el número de usuarios (U): \n"))
gastos_totales = float(input("Ingrese los gastos totales (GT): \n"))

# Calcular las utilidades según la fórmula
utilidades = precio_suscripcion * num_usuarios - gastos_totales

# Imprimir el resultado
print(f"Las utilidades del proyecto son: {utilidades:.2f} USD")